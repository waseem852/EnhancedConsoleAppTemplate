﻿namespace $safeprojectname$
{
    public interface IGreetingService
    {
        void Run();
    }
}