﻿namespace $safeprojectname$.Configs
{
    public class ExampleSettings
    {
        public string Settings1 { get; set; }
        public int Settings2 { get; set; }
        public bool Settings3 { get; set; }


    }
}
